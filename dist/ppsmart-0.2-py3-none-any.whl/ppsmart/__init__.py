def joke():
    return """
        This is a joke!!!!
    """